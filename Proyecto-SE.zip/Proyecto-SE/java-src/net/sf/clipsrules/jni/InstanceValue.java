package net.sf.clipsrules.jni;

public abstract class InstanceValue extends PrimitiveValue
  {
   /******************/
   /* InstanceValue: */
   /******************/
   public InstanceValue(
     String value)
     {
      super(value);
     }

   /******************/
   /* InstanceValue: */
   /******************/
   public InstanceValue(
     Long value)
     {
      super(value);
     }
  }
